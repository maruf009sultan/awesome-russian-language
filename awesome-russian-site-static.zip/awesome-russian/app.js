/**
 * Main Application - Awesome Russian Language
 * Premium dark theme with cohesive violet-indigo + amber palette
 */

// Category accent colors — all using the new palette
const CAT_COLORS = [
  'linear-gradient(135deg, #7c3aed, #a78bfa)',
  'linear-gradient(135deg, #10b981, #34d399)',
  'linear-gradient(135deg, #f59e0b, #fbbf24)',
  'linear-gradient(135deg, #3b82f6, #60a5fa)',
  'linear-gradient(135deg, #f43f5e, #fb7185)',
  'linear-gradient(135deg, #06b6d4, #22d3ee)',
  'linear-gradient(135deg, #f97316, #fb923c)',
  'linear-gradient(135deg, #8b5cf6, #c4b5fd)',
  'linear-gradient(135deg, #14b8a6, #5eead4)',
  'linear-gradient(135deg, #ec4899, #f472b6)',
];

// Level badge colors — updated to new palette
const LEVEL_COLORS = {
  'A1': { bg: 'rgba(16, 185, 129, 0.1)', color: '#10b981' },
  'A2': { bg: 'rgba(6, 182, 212, 0.1)', color: '#06b6d4' },
  'B1': { bg: 'rgba(124, 58, 237, 0.1)', color: '#a78bfa' },
  'B2': { bg: 'rgba(59, 130, 246, 0.1)', color: '#3b82f6' },
  'C1': { bg: 'rgba(249, 115, 22, 0.1)', color: '#f97316' },
  'C2': { bg: 'rgba(244, 63, 94, 0.1)', color: '#f43f5e' },
  'All': { bg: 'rgba(245, 158, 11, 0.1)', color: '#f59e0b' },
};

const PRICING_STYLES = {
  'free': { bg: 'rgba(16, 185, 129, 0.1)', color: '#10b981', label: 'Free' },
  'freemium': { bg: 'rgba(249, 115, 22, 0.1)', color: '#f97316', label: 'Freemium' },
  'paid': { bg: 'rgba(244, 63, 94, 0.1)', color: '#f43f5e', label: 'Paid' },
};

// ===== INITIALIZATION =====
let appData = null;
window._appData = null;

async function initApp() {
  try {
    appData = await getData();
    window._appData = appData;

    renderSidebar();
    populateQuizCategories(appData);
    createParticles();
    updateCacheStatus();
    setupEventListeners();
    handleRoute();

    const loader = document.getElementById('loadingScreen');
    if (loader) {
      loader.style.opacity = '0';
      loader.style.transition = 'opacity 0.3s ease';
      setTimeout(() => loader.remove(), 300);
    }

  } catch(err) {
    console.error('Failed to initialize:', err);
    document.getElementById('mainContent').innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">⚠️</div>
        <h2>Failed to Load Resources</h2>
        <p>Could not fetch the README.md. Please try again later.</p>
        <p style="color: var(--text-muted); font-size: 0.8rem; margin-top: 8px;">Error: ${err.message}</p>
        <div style="display:flex;gap:12px;justify-content:center;margin-top:16px">
          <button class="btn-primary" onclick="location.reload()">Retry</button>
          <button class="btn-secondary" onclick="forceRefresh()">Force Refresh</button>
        </div>
      </div>
    `;
  }
}

// ===== CACHE STATUS =====
function updateCacheStatus() {
  const el = document.getElementById('cacheStatus');
  if (!el) return;
  const age = getCacheAge();
  const fresh = isCacheFresh();
  el.innerHTML = `<span class="cache-dot ${fresh ? 'fresh' : 'stale'}"></span> Updated ${age}`;
}

// ===== SIDEBAR =====
function renderSidebar() {
  const nav = document.getElementById('sidebarNav');
  nav.innerHTML = '';
  appData.categories.forEach((cat, i) => {
    const li = document.createElement('li');
    li.innerHTML = `
      <a href="#/category/${cat.id}">
        <span class="cat-emoji">${cat.emoji}</span>
        <span>${cat.name}</span>
        <span class="cat-count">${cat.count}</span>
      </a>
    `;
    nav.appendChild(li);
  });
}

// ===== ROUTES =====
route('/', renderHomePage);
route('/daily', renderDailyQuizPage);
route('/category/:slug', renderCategoryPage);
route('/search', renderSearchPage);
route('404', render404);

// ===== HOME PAGE =====
function renderHomePage() {
  const main = document.getElementById('mainContent');

  const totalResources = appData.metadata.totalResources;
  const totalCategories = appData.categories.length;
  const freeResources = getAllResources(appData).filter(r => r.pricing === 'free').length;

  let cardsHTML = '';
  appData.categories.forEach((cat, i) => {
    const colorIdx = i % CAT_COLORS.length;
    const freeCount = [...cat.resources, ...cat.subsections.flatMap(s => s.resources)].filter(r => r.pricing === 'free').length;
    const levels = [...new Set([...cat.resources, ...cat.subsections.flatMap(s => s.resources)].map(r => r.level))];
    const mainLevel = levels[0] || 'All';

    cardsHTML += `
      <div class="category-card" style="--card-accent: ${CAT_COLORS[colorIdx]}" onclick="navigate('/category/${cat.id}')">
        <div class="card-header">
          <div class="card-emoji">${cat.emoji}</div>
          <div class="card-info">
            <h3>${cat.name}</h3>
            <span class="card-count">${cat.count} resource${cat.count !== 1 ? 's' : ''}</span>
          </div>
        </div>
        <p class="card-desc">${cat.description || 'Explore ' + cat.count + ' curated resources for ' + cat.name.toLowerCase()}</p>
        <div class="card-footer">
          <div class="card-tags">
            ${freeCount > 0 ? `<span class="tag tag-free">Free</span>` : ''}
            ${cat.count - freeCount > 0 ? `<span class="tag tag-mixed">Mixed</span>` : ''}
            <span class="tag tag-level">${mainLevel}</span>
          </div>
          <span class="card-arrow">→</span>
        </div>
      </div>
    `;
  });

  main.innerHTML = `
    <div class="hero">
      <div class="hero-flag">🇷🇺</div>
      <h1><span class="gradient-text">Awesome Russian Language</span></h1>
      <p class="hero-russian">Добро пожаловать!</p>
      <p class="subtitle">A curated collection of <strong>${totalResources}+</strong> resources for English speakers learning Russian — from beginner to advanced, from grammar to culture.</p>
      <div class="hero-stats">
        <div class="hero-stat">
          <div class="hero-stat-value">${totalResources}+</div>
          <div class="hero-stat-label">Resources</div>
        </div>
        <div class="hero-stat">
          <div class="hero-stat-value">${totalCategories}</div>
          <div class="hero-stat-label">Categories</div>
        </div>
        <div class="hero-stat">
          <div class="hero-stat-value">${freeResources}+</div>
          <div class="hero-stat-label">Free</div>
        </div>
        <div class="hero-stat">
          <div class="hero-stat-value">A1→C2</div>
          <div class="hero-stat-label">CEFR Levels</div>
        </div>
      </div>
      <div class="hero-actions">
        <button class="btn-primary" onclick="openQuiz()">🧠 Take a Quiz</button>
        <a href="#/daily" class="btn-secondary" style="text-decoration:none">📅 Daily Practice</a>
        <button class="btn-secondary" onclick="openStats()">📊 View Stats</button>
        <a href="https://github.com/maruf009sultan/awesome-russian-language" target="_blank" class="btn-secondary">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.3 3.438 9.8 8.205 11.387.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.605-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 21.795 24 17.295 24 12c0-6.63-5.37-12-12-12z"/></svg>
          GitHub
        </a>
      </div>
    </div>

    <div class="section-title">Browse Categories</div>
    <div class="category-grid">
      ${cardsHTML}
    </div>

    ${renderDailyWordSection()}

    <div class="contribute-cta">
      <h2>🤝 Help Grow This Collection</h2>
      <p>Know a great Russian learning resource? Share it with the community! Contribute to the repo, share with friends, and help others learn Russian.</p>
      <div class="cta-buttons">
        <a href="https://github.com/maruf009sultan/awesome-russian-language/pulls" target="_blank" class="btn-primary">🤝 Contribute Resources</a>
        <button class="btn-secondary" onclick="shareSite()">📢 Share with Friends</button>
        <a href="https://github.com/maruf009sultan/awesome-russian-language/stargazers" target="_blank" class="btn-secondary">⭐ Star on GitHub</a>
      </div>
    </div>
  `;
}

// ===== CATEGORY PAGE =====
function renderCategoryPage(slug) {
  const cat = appData.categories.find(c => c.id === slug);
  if (!cat) {
    render404();
    return;
  }

  const main = document.getElementById('mainContent');
  const allResources = [...cat.resources, ...cat.subsections.flatMap(s => s.resources)];
  const freeCount = allResources.filter(r => r.pricing === 'free').length;
  const levels = [...new Set(allResources.map(r => r.level))];

  let resourceListHTML = '';

  if (cat.resources.length > 0) {
    resourceListHTML += cat.resources.map((r, i) => renderResourceItem(r, i + 1, cat)).join('');
  }

  cat.subsections.forEach(sub => {
    resourceListHTML += `
      <div class="subsection">
        <h3>${sub.emoji ? sub.emoji + ' ' : ''}${sub.name}</h3>
        <div class="resource-list">
          ${sub.resources.map((r, i) => renderResourceItem(r, i + 1, cat)).join('')}
        </div>
      </div>
    `;
  });

  if (allResources.length === 0) {
    resourceListHTML = `
      <div class="empty-state">
        <div class="empty-icon">📭</div>
        <p>No resources parsed yet for this category.</p>
      </div>
    `;
  }

  main.innerHTML = `
    <div class="category-page">
      <div class="breadcrumb">
        <a href="#/">Home</a>
        <span>/</span>
        <span>${cat.emoji} ${cat.name}</span>
      </div>

      <div class="category-hero">
        <div class="category-hero-top">
          <div class="category-hero-left">
            <div class="category-hero-emoji">${cat.emoji}</div>
            <div>
              <h1>${cat.name}</h1>
            </div>
          </div>
          <div class="resource-actions">
            <button class="btn-secondary btn-sm" onclick="shareCategory('${cat.id}')" title="Share this category">
              📢 Share
            </button>
            <button class="btn-icon" onclick="copyCategoryLink('${cat.id}')" title="Copy link">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
            </button>
          </div>
        </div>
        ${cat.description ? `<p class="cat-description">${cat.description}</p>` : ''}
        <div class="cat-meta">
          <div class="cat-meta-item"><strong>${cat.count}</strong> resources</div>
          ${freeCount > 0 ? `<div class="cat-meta-item"><strong>${freeCount}</strong> free</div>` : ''}
          ${levels.length > 0 ? `<div class="cat-meta-item">Levels: <strong>${levels.join(', ')}</strong></div>` : ''}
        </div>
      </div>

      <div class="resource-controls">
        <div class="filter-group">
          <button class="filter-btn active" data-filter="all" onclick="filterResources(this, 'all')">All</button>
          <button class="filter-btn" data-filter="free" onclick="filterResources(this, 'free')">🆓 Free</button>
          <button class="filter-btn" data-filter="freemium" onclick="filterResources(this, 'freemium')">⭐ Freemium</button>
          <button class="filter-btn" data-filter="paid" onclick="filterResources(this, 'paid')">💰 Paid</button>
        </div>
      </div>

      <div class="resource-list" id="resourceList">
        ${resourceListHTML}
      </div>

      <div class="contribute-cta">
        <h2>🤝 Know a Resource for ${cat.name}?</h2>
        <p>Help expand this category! Contribute to the repo and share with fellow Russian learners.</p>
        <div class="cta-buttons">
          <a href="https://github.com/maruf009sultan/awesome-russian-language/pulls" target="_blank" class="btn-primary">🤝 Contribute</a>
          <button class="btn-secondary" onclick="shareCategory('${cat.id}')">📢 Share Category</button>
        </div>
      </div>
    </div>
  `;

  // Update SEO for category page
  updateSEO(
    `${cat.name} — ${cat.count} Russian Learning Resources`,
    `Explore ${cat.count} curated resources for learning ${cat.name}. ${cat.description || 'Free and premium resources for Russian language learners.'}`,
    window.location.origin + window.location.pathname + '#/category/' + cat.id
  );
}

function renderResourceItem(resource, num, category) {
  const levelStyle = LEVEL_COLORS[resource.level] || LEVEL_COLORS['All'];
  const pricingStyle = PRICING_STYLES[resource.pricing] || PRICING_STYLES['free'];
  const iconStr = resource.icons.map(i => {
    const iconMap = { 'Video': '▶️', 'GitHub': '📦', 'PDF': '📄', 'Audio': '🎙️', 'App': '📱', 'Reference': '📖' };
    return iconMap[i] || '';
  }).join('');

  return `
    <div class="resource-item" data-pricing="${resource.pricing}" data-level="${resource.level}">
      <span class="resource-num">${num}</span>
      <div class="resource-content">
        <div class="resource-name">
          ${iconStr ? `<span class="res-icon">${iconStr}</span>` : ''}
          ${resource.url ? `<a href="${resource.url}" target="_blank" rel="noopener">${resource.name}</a>` : resource.name}
        </div>
        <div class="resource-desc">${resource.description}</div>
        <div class="resource-tags">
          <span class="tag" style="background:${pricingStyle.bg};color:${pricingStyle.color}">${pricingStyle.label}</span>
          <span class="tag" style="background:${levelStyle.bg};color:${levelStyle.color}">${resource.level}</span>
        </div>
      </div>
      <div class="resource-actions">
        ${resource.url ? `
          <button class="btn-icon" onclick="event.stopPropagation(); copyResourceLink('${resource.url}', '${resource.name.replace(/'/g, "\\'")}')" title="Copy link">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
          </button>
          <button class="btn-icon" onclick="event.stopPropagation(); shareResource('${resource.url}', '${resource.name.replace(/'/g, "\\'")}')" title="Share">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
          </button>
        ` : ''}
      </div>
    </div>
  `;
}

// ===== FILTER =====
function filterResources(btn, filter) {
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.resource-item').forEach(item => {
    item.style.display = filter === 'all' ? '' : (item.dataset.pricing === filter ? '' : 'none');
  });
}

// ===== SEARCH =====
function renderSearchPage(query) {
  const results = searchResources(query, appData);
  const main = document.getElementById('mainContent');

  let resultsHTML = '';
  if (results.length > 0) {
    resultsHTML = `<div class="resource-list">` +
      results.map((r, i) => renderResourceItem(r, i + 1, { emoji: r.categoryEmoji })) +
      `</div>`;
  } else {
    resultsHTML = `
      <div class="empty-state">
        <div class="empty-icon">🔍</div>
        <p>No resources found for "${query}". Try a different search term.</p>
      </div>
    `;
  }

  main.innerHTML = `
    <div class="search-results-page">
      <div class="breadcrumb">
        <a href="#/">Home</a>
        <span>/</span>
        <span>Search</span>
      </div>
      <div class="search-results-header">
        <h2>Search Results for "${query}"</h2>
        <p>${results.length} resource${results.length !== 1 ? 's' : ''} found</p>
      </div>
      ${resultsHTML}
    </div>
  `;
}

// ===== 404 =====
function render404() {
  document.getElementById('mainContent').innerHTML = `
    <div class="empty-state">
      <div class="empty-icon">🤷</div>
      <h2>Page Not Found</h2>
      <p>The page you're looking for doesn't exist.</p>
      <a href="#/" class="btn-primary" style="margin-top: 16px;">Go Home</a>
    </div>
  `;
}

// ===== STATS =====
function openStats() {
  const allRes = getAllResources(appData);
  const freeCount = allRes.filter(r => r.pricing === 'free').length;
  const freemiumCount = allRes.filter(r => r.pricing === 'freemium').length;
  const paidCount = allRes.filter(r => r.pricing === 'paid').length;

  const levelDist = {};
  allRes.forEach(r => { levelDist[r.level] = (levelDist[r.level] || 0) + 1; });

  const topCats = [...appData.categories].sort((a, b) => b.count - a.count).slice(0, 8);
  const maxCatCount = topCats[0]?.count || 1;

  const levelOrder = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2', 'All'];
  const maxLevel = Math.max(...Object.values(levelDist), 1);

  document.getElementById('statsBody').innerHTML = `
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-value">${appData.metadata.totalResources}+</div>
        <div class="stat-label">Total Resources</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${appData.categories.length}</div>
        <div class="stat-label">Categories</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${freeCount}</div>
        <div class="stat-label">Free Resources</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${Math.round(freeCount / allRes.length * 100)}%</div>
        <div class="stat-label">Free Percentage</div>
      </div>
    </div>

    <div class="stats-chart">
      <h4>📊 Top Categories</h4>
      ${topCats.map(cat => `
        <div class="chart-bar">
          <span class="chart-bar-label">${cat.emoji} ${cat.name}</span>
          <div class="chart-bar-track">
            <div class="chart-bar-fill" style="width: ${(cat.count / maxCatCount * 100)}%"></div>
          </div>
          <span class="chart-bar-value">${cat.count}</span>
        </div>
      `).join('')}
    </div>

    <div class="stats-chart" style="margin-top: 16px;">
      <h4>📈 CEFR Level Distribution</h4>
      ${levelOrder.map(level => {
        const count = levelDist[level] || 0;
        return `
          <div class="chart-bar">
            <span class="chart-bar-label">${level}</span>
            <div class="chart-bar-track">
              <div class="chart-bar-fill" style="width: ${(count / maxLevel * 100)}%; background: ${(LEVEL_COLORS[level] || LEVEL_COLORS['All']).color}"></div>
            </div>
            <span class="chart-bar-value">${count}</span>
          </div>
        `;
      }).join('')}
    </div>

    <div class="stats-chart" style="margin-top: 16px;">
      <h4>💰 Pricing Distribution</h4>
      <div class="chart-bar">
        <span class="chart-bar-label">🆓 Free</span>
        <div class="chart-bar-track">
          <div class="chart-bar-fill" style="width: ${(freeCount / allRes.length * 100)}%; background: var(--green)"></div>
        </div>
        <span class="chart-bar-value">${freeCount}</span>
      </div>
      <div class="chart-bar">
        <span class="chart-bar-label">⭐ Freemium</span>
        <div class="chart-bar-track">
          <div class="chart-bar-fill" style="width: ${(freemiumCount / allRes.length * 100)}%; background: var(--orange)"></div>
        </div>
        <span class="chart-bar-value">${freemiumCount}</span>
      </div>
      <div class="chart-bar">
        <span class="chart-bar-label">💰 Paid</span>
        <div class="chart-bar-track">
          <div class="chart-bar-fill" style="width: ${(paidCount / allRes.length * 100)}%; background: var(--red)"></div>
        </div>
        <span class="chart-bar-value">${paidCount}</span>
      </div>
    </div>
  `;

  document.getElementById('statsModal').classList.add('active');
}

function closeStats() { document.getElementById('statsModal').classList.remove('active'); }

// ===== SHARE =====
function shareSite() {
  const url = window.location.origin + window.location.pathname;
  const text = 'Check out this awesome collection of 780+ Russian language learning resources! 🇷🇺';
  showShareModal(url, text, 'Awesome Russian Language');
}

function shareCategory(catId) {
  const cat = appData.categories.find(c => c.id === catId);
  if (!cat) return;
  const url = window.location.origin + window.location.pathname + '#/category/' + catId;
  const text = `Check out ${cat.count}+ resources for learning ${cat.name} 🇷🇺`;
  showShareModal(url, text, cat.emoji + ' ' + cat.name);
}

function shareResource(resourceUrl, name) {
  const text = `Check out this Russian learning resource: ${name} 🇷🇺`;
  showShareModal(resourceUrl, text, name);
}

function showShareModal(url, text, title) {
  document.getElementById('shareBody').innerHTML = `
    <p style="color: var(--text-secondary); margin-bottom: 16px; font-size: 0.88rem;">Share "${title}" with fellow Russian learners!</p>
    <div class="share-options">
      <button class="share-option" onclick="shareViaTwitter('${encodeURIComponent(text)}', '${encodeURIComponent(url)}')">
        <span class="share-icon">𝕏</span> Share on Twitter/X
      </button>
      <button class="share-option" onclick="shareViaTelegram('${encodeURIComponent(text)}', '${encodeURIComponent(url)}')">
        <span class="share-icon">✈️</span> Share on Telegram
      </button>
      <button class="share-option" onclick="shareViaWhatsApp('${encodeURIComponent(text)}', '${encodeURIComponent(url)}')">
        <span class="share-icon">💬</span> Share on WhatsApp
      </button>
      <button class="share-option" onclick="shareViaEmail('${encodeURIComponent(title)}', '${encodeURIComponent(text + ' ' + url)}')">
        <span class="share-icon">📧</span> Share via Email
      </button>
    </div>
    <div class="share-link-box">
      <input type="text" value="${url}" readonly id="shareLinkInput" onclick="this.select()">
      <button class="btn-primary btn-sm" onclick="copyShareLink()">Copy</button>
    </div>
  `;
  document.getElementById('shareModal').classList.add('active');
}

function closeShare() { document.getElementById('shareModal').classList.remove('active'); }

function shareViaTwitter(text, url) { window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank'); }
function shareViaTelegram(text, url) { window.open(`https://t.me/share/url?url=${url}&text=${text}`, '_blank'); }
function shareViaWhatsApp(text, url) { window.open(`https://wa.me/?text=${text}%20${url}`, '_blank'); }
function shareViaEmail(subject, body) { window.location.href = `mailto:?subject=${subject}&body=${body}`; }

function copyShareLink() {
  const input = document.getElementById('shareLinkInput');
  input.select();
  navigator.clipboard.writeText(input.value).then(() => {
    showToast('Link copied to clipboard!', 'success');
  }).catch(() => {
    document.execCommand('copy');
    showToast('Link copied!', 'success');
  });
}

function copyResourceLink(url, name) {
  navigator.clipboard.writeText(url).then(() => {
    showToast(`Link copied for "${name}"`, 'success');
  }).catch(() => {
    showToast('Failed to copy link', 'error');
  });
}

function copyCategoryLink(catId) {
  const url = window.location.origin + window.location.pathname + '#/category/' + catId;
  navigator.clipboard.writeText(url).then(() => {
    showToast('Category link copied!', 'success');
  }).catch(() => {
    showToast('Failed to copy link', 'error');
  });
}

// ===== TOAST =====
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

// ===== PARTICLES =====
function createParticles() {
  const app = document.getElementById('app');
  const particlesDiv = document.createElement('div');
  particlesDiv.className = 'particles';
  app.insertBefore(particlesDiv, app.firstChild);

  const letters = 'АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЩЭЮЯ';
  for (let i = 0; i < 12; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.textContent = letters[Math.floor(Math.random() * letters.length)];
    p.style.cssText = `
      left: ${Math.random() * 100}%;
      font-size: ${10 + Math.random() * 16}px;
      animation-duration: ${20 + Math.random() * 30}s;
      animation-delay: ${Math.random() * 25}s;
    `;
    particlesDiv.appendChild(p);
  }
}

// ===== EVENT LISTENERS =====
function setupEventListeners() {
  // Navbar scroll effect
  window.addEventListener('scroll', () => {
    document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 10);
    document.getElementById('backToTop').classList.toggle('visible', window.scrollY > 400);
  });

  // Back to top
  document.getElementById('backToTop').addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  // Search
  const searchInput = document.getElementById('searchInput');
  let searchTimeout;
  searchInput.addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      const q = e.target.value.trim();
      if (q.length >= 2) {
        navigate('/search?q=' + encodeURIComponent(q));
      } else if (q.length === 0 && currentRoute.startsWith('/search')) {
        navigate('/');
      }
    }, 300);
  });

  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    if (e.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) {
      e.preventDefault();
      searchInput.focus();
    }
    if (e.key === 'Escape') {
      closeQuiz();
      closeStats();
      closeShare();
      searchInput.blur();
    }
  });

  // Sidebar toggle
  document.getElementById('menuToggle').addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').classList.toggle('active');
  });

  document.getElementById('sidebarClose').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.remove('active');
  });

  document.getElementById('sidebarOverlay').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.remove('active');
  });

  // Quiz button
  document.getElementById('quizBtn').addEventListener('click', openQuiz);

  // Stats button
  document.getElementById('statsBtn').addEventListener('click', openStats);

  // Footer share
  document.getElementById('shareFooterBtn').addEventListener('click', shareSite);

  // Close modals on overlay click
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) overlay.classList.remove('active');
    });
  });

  // Update cache status every minute
  setInterval(updateCacheStatus, 60000);
}

// ===== START APP =====
initApp();
