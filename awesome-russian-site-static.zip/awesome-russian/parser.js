/**
 * Markdown Parser for Awesome Russian Language README
 * - Caches in localStorage with daily auto-refresh
 * - Falls back to CORS proxy for GitHub
 * - Manual refresh via forceRefresh()
 */

const README_URL = 'https://raw.githubusercontent.com/maruf009sultan/awesome-russian-language/refs/heads/main/README.md';
const CORS_PROXIES = [
  '', // direct fetch first
  'https://api.allorigins.win/raw?url=',
  'https://corsproxy.io/?',
];

const CACHE_KEY = 'awesomeRussian_readme';
const CACHE_TIMESTAMP_KEY = 'awesomeRussian_readme_ts';
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours in ms

let cachedData = null;
let rawMarkdown = '';

/**
 * Check if cache is still fresh (< 24h old)
 */
function isCacheFresh() {
  const ts = localStorage.getItem(CACHE_TIMESTAMP_KEY);
  if (!ts) return false;
  return (Date.now() - parseInt(ts)) < CACHE_DURATION;
}

/**
 * Get cached markdown from localStorage
 */
function getCachedMarkdown() {
  const cached = localStorage.getItem(CACHE_KEY);
  if (cached && cached.includes('Awesome Russian')) {
    return cached;
  }
  return null;
}

/**
 * Save markdown to localStorage cache
 */
function cacheMarkdown(md) {
  try {
    localStorage.setItem(CACHE_KEY, md);
    localStorage.setItem(CACHE_TIMESTAMP_KEY, Date.now().toString());
  } catch(e) {
    // localStorage might be full, clear old data
    try {
      localStorage.removeItem(CACHE_KEY);
      localStorage.removeItem(CACHE_TIMESTAMP_KEY);
      localStorage.setItem(CACHE_KEY, md);
      localStorage.setItem(CACHE_TIMESTAMP_KEY, Date.now().toString());
    } catch(e2) {
      console.warn('Could not cache README:', e2);
    }
  }
}

/**
 * Force refresh — clears cache and re-fetches
 */
async function forceRefresh() {
  localStorage.removeItem(CACHE_KEY);
  localStorage.removeItem(CACHE_TIMESTAMP_KEY);
  cachedData = null;
  rawMarkdown = '';

  const btn = document.getElementById('refreshBtn');
  if (btn) btn.classList.add('spin');

  try {
    const md = await fetchReadme(true);
    cachedData = parseReadme(md);
    window._appData = cachedData;

    // Re-render current page
    if (typeof handleRoute === 'function') handleRoute();
    if (typeof renderSidebar === 'function') renderSidebar();

    showToast('Resources refreshed from GitHub!', 'success');
  } catch(e) {
    showToast('Failed to refresh: ' + e.message, 'error');
  }

  if (btn) setTimeout(() => btn.classList.remove('spin'), 800);
  return cachedData;
}

/**
 * Get cache age string for display
 */
function getCacheAge() {
  const ts = localStorage.getItem(CACHE_TIMESTAMP_KEY);
  if (!ts) return 'never';
  const diff = Date.now() - parseInt(ts);
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

/**
 * Fetch README.md with caching + CORS proxy fallback
 */
async function fetchReadme(skipCache = false) {
  // 1. Try localStorage cache (if fresh and not forcing refresh)
  if (!skipCache && isCacheFresh()) {
    const cached = getCachedMarkdown();
    if (cached) {
      rawMarkdown = cached;
      console.log('Loaded README.md from localStorage cache');
      return cached;
    }
  }

  // 2. Try local file first (for Cloudflare Pages deployment)
  try {
    const localResp = await fetch('./README.md');
    if (localResp.ok) {
      const text = await localResp.text();
      if (text && text.includes('Awesome Russian')) {
        rawMarkdown = text;
        cacheMarkdown(text);
        console.log('Loaded README.md from local file');
        return text;
      }
    }
  } catch(e) { /* no local file */ }

  // 3. Try remote with CORS proxies
  for (const proxy of CORS_PROXIES) {
    try {
      const fetchUrl = proxy === '' ? README_URL : (proxy + encodeURIComponent(README_URL));
      const resp = await fetch(fetchUrl, { cache: 'no-cache' });
      if (resp.ok) {
        const text = await resp.text();
        if (text && text.includes('Awesome Russian')) {
          rawMarkdown = text;
          cacheMarkdown(text);
          console.log('Loaded README.md from:', fetchUrl.substring(0, 60) + '...');
          return text;
        }
      }
    } catch(e) {
      console.warn('Failed to fetch from proxy:', proxy, e.message);
    }
  }

  // 4. Last resort: use stale cache if available
  if (!skipCache) {
    const stale = getCachedMarkdown();
    if (stale) {
      rawMarkdown = stale;
      console.log('Using stale cache as fallback');
      return stale;
    }
  }

  throw new Error('Could not fetch README.md from any source');
}

/**
 * Parse markdown into structured category data
 */
function parseReadme(markdown) {
  const lines = markdown.split('\n');
  const categories = [];
  let currentCategory = null;
  let currentSubsection = null;
  let inTable = false;
  let metadata = {
    totalResources: 0,
    totalCategories: 0,
    title: '',
    subtitle: '',
    description: '',
    russianWelcome: '',
    quickStats: {},
  };

  // Extract metadata from the top section
  const titleMatch = markdown.match(/^#\s+(.+)$/m);
  if (titleMatch) metadata.title = titleMatch[1];

  const subtitleMatch = markdown.match(/^###\s+(A Curated.+)$/m);
  if (subtitleMatch) metadata.subtitle = subtitleMatch[1];

  const quoteMatch = markdown.match(/^>\s+\*([^*]+)\*.*Welcome[^.]*\.\s*(.+)$/m);
  if (quoteMatch) {
    metadata.russianWelcome = quoteMatch[1].trim();
  }

  // Try to extract total resource count
  const countMatch = markdown.match(/(\d+)\+\s*resources/i) || markdown.match(/Resources.*?(\d+)\+/i);
  if (countMatch) metadata.totalResources = parseInt(countMatch[1]);

  // Parse categories from ## headings
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    const h2Match = line.match(/^##\s+(.+)$/);
    if (h2Match) {
      const heading = h2Match[1];
      const skipSections = ['Table of Contents', 'How to Use', 'What\'s New', 'Contributing', 'Learning Roadmap', 'Editor\'s Picks', 'Resource Statistics', 'CEFR Level Guide'];
      if (skipSections.some(s => heading.includes(s))) {
        currentCategory = null;
        currentSubsection = null;
        continue;
      }

      const emojiMatch = heading.match(/^(\p{Emoji_Presentation}|\p{Emoji}\uFE0F)\s*/u);
      const emoji = emojiMatch ? emojiMatch[1] : '';
      const name = heading.replace(/^(\p{Emoji_Presentation}|\p{Emoji}\uFE0F)\s*/u, '').trim();

      let description = '';
      for (let j = i + 1; j < Math.min(i + 5, lines.length); j++) {
        const descMatch = lines[j].match(/^>\s*(?:🎯\s*)?\*([^*]+)\*/);
        if (descMatch) {
          description = descMatch[1].trim();
          break;
        }
        if (lines[j].startsWith('##') || lines[j].startsWith('|')) break;
      }

      let count = 0;

      currentCategory = {
        id: slugify(name),
        emoji,
        name,
        heading,
        description,
        resources: [],
        subsections: [],
        count
      };
      categories.push(currentCategory);
      currentSubsection = null;
      inTable = false;
      continue;
    }

    const h3Match = line.match(/^###\s+(.+)$/);
    if (h3Match && currentCategory) {
      currentSubsection = {
        name: h3Match[1].replace(/^[\p{Emoji_Presentation}\p{Emoji}\uFE0F]+\s*/u, '').trim(),
        emoji: (h3Match[1].match(/^(\p{Emoji_Presentation}|\p{Emoji}\uFE0F)/u) || ['',''])[1],
        resources: []
      };
      currentCategory.subsections.push(currentSubsection);
      inTable = false;
      continue;
    }

    if (currentCategory && line.startsWith('|')) {
      if (line.match(/^\|[\s:-]+\|/)) continue;

      if (!inTable && line.includes('Resource') && line.includes('Description')) {
        inTable = true;
        continue;
      }

      if (inTable) {
        const cells = line.split('|').map(c => c.trim()).filter(Boolean);
        if (cells.length >= 3) {
          const resource = parseResourceRow(cells);
          if (resource) {
            if (currentSubsection) {
              currentSubsection.resources.push(resource);
            } else {
              currentCategory.resources.push(resource);
            }
          }
        }
      }
    } else if (currentCategory && inTable && !line.startsWith('|')) {
      inTable = false;
    }

    if (currentCategory && line.includes('Show all') && line.includes('resources')) {
      continue;
    }
  }

  // Calculate counts
  let totalResources = 0;
  categories.forEach(cat => {
    cat.count = cat.resources.length + cat.subsections.reduce((s, sub) => s + sub.resources.length, 0);
    totalResources += cat.count;
  });

  metadata.totalCategories = categories.length;
  if (totalResources > metadata.totalResources || metadata.totalResources === 0) {
    metadata.totalResources = totalResources;
  }

  cachedData = { metadata, categories };
  return cachedData;
}

/**
 * Parse a table row into a resource object
 */
function parseResourceRow(cells) {
  if (cells.length < 3) return null;

  const numCell = cells[0] || '';
  const resourceCell = cells[1] || '';
  const descCell = cells[2] || '';
  const levelCell = cells[3] || '';

  if (numCell === '#' || numCell.toLowerCase() === 'resource') return null;

  const linkMatch = resourceCell.match(/\[([^\]]+)\]\(([^)]+)\)/);
  const name = linkMatch ? linkMatch[1] : resourceCell.replace(/[*_`]/g, '').trim();
  const url = linkMatch ? linkMatch[2] : '';

  if (!name || name === 'Your new resource here') return null;

  const icons = [];
  let cleanName = name;
  const iconPatterns = [
    { regex: /▶️/g, label: 'Video' },
    { regex: /📦/g, label: 'GitHub' },
    { regex: /📄/g, label: 'PDF' },
    { regex: /🎙️/g, label: 'Audio' },
    { regex: /📱/g, label: 'App' },
    { regex: /📖/g, label: 'Reference' },
  ];
  iconPatterns.forEach(p => {
    if (p.regex.test(cleanName)) {
      icons.push(p.label);
      cleanName = cleanName.replace(p.regex, '').trim();
    }
  });

  let cleanDesc = descCell
    .replace(/<[^>]+>/g, '')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/[*_`]/g, '')
    .trim();

  let pricing = 'free';
  if (cleanDesc.includes('[Paid]')) pricing = 'paid';
  else if (cleanDesc.includes('[Freemium]')) pricing = 'freemium';
  cleanDesc = cleanDesc.replace(/\[(Free|Paid|Freemium)\]/g, '').trim();

  const level = levelCell.replace(/[*_`]/g, '').trim() || 'All';

  return {
    id: slugify(cleanName),
    name: cleanName,
    url,
    description: cleanDesc,
    level,
    pricing,
    icons,
    number: parseInt(numCell) || 0
  };
}

function slugify(text) {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .substring(0, 60);
}

function getAllResources(data) {
  const resources = [];
  data.categories.forEach(cat => {
    cat.resources.forEach(r => resources.push({ ...r, category: cat.name, categoryId: cat.id, categoryEmoji: cat.emoji }));
    cat.subsections.forEach(sub => {
      sub.resources.forEach(r => resources.push({ ...r, category: cat.name, categoryId: cat.id, categoryEmoji: cat.emoji, subsection: sub.name }));
    });
  });
  return resources;
}

function searchResources(query, data) {
  if (!query || query.length < 2) return [];
  const q = query.toLowerCase();
  const results = [];

  data.categories.forEach(cat => {
    if (cat.name.toLowerCase().includes(q) || cat.description.toLowerCase().includes(q)) {
      cat.resources.forEach(r => results.push({ ...r, category: cat.name, categoryId: cat.id, categoryEmoji: cat.emoji }));
      cat.subsections.forEach(sub => {
        sub.resources.forEach(r => results.push({ ...r, category: cat.name, categoryId: cat.id, categoryEmoji: cat.emoji, subsection: sub.name }));
      });
      return;
    }

    cat.resources.forEach(r => {
      if (r.name.toLowerCase().includes(q) || r.description.toLowerCase().includes(q)) {
        results.push({ ...r, category: cat.name, categoryId: cat.id, categoryEmoji: cat.emoji });
      }
    });
    cat.subsections.forEach(sub => {
      sub.resources.forEach(r => {
        if (r.name.toLowerCase().includes(q) || r.description.toLowerCase().includes(q)) {
          results.push({ ...r, category: cat.name, categoryId: cat.id, categoryEmoji: cat.emoji, subsection: sub.name });
        }
      });
    });
  });

  return results;
}

async function getData() {
  if (cachedData) return cachedData;
  const md = await fetchReadme();
  return parseReadme(md);
}
