/**
 * Daily Quiz Module — Deterministic date-based question selection
 * Everyone gets the same questions on the same day worldwide!
 */

// ===== SEEDED PRNG (mulberry32) =====
function mulberry32(seed) {
  return function() {
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

// Convert date string "YYYY-MM-DD" to a seed number
function dateSeed(dateStr) {
  let hash = 0;
  for (let i = 0; i < dateStr.length; i++) {
    const ch = dateStr.charCodeAt(i);
    hash = ((hash << 5) - hash) + ch;
    hash |= 0;
  }
  return Math.abs(hash);
}

// Get today's date string in YYYY-MM-DD
function getTodayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

// Format date for display: "May 11, 2026"
function formatDate(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
}

// Deterministic shuffle using seed
function seededShuffle(arr, rng) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// Get daily questions (10 questions deterministically picked for today)
function getDailyQuestions(customDate) {
  const dateStr = customDate || getTodayStr();
  const seed = dateSeed(dateStr);
  const rng = mulberry32(seed);

  // Deterministic shuffle and pick 10
  const shuffled = seededShuffle(quizQuestions, rng);
  return {
    questions: shuffled.slice(0, 10),
    dateStr,
    seed
  };
}

// Daily quiz state
let dailyState = {
  questions: [],
  dateStr: '',
  currentIndex: 0,
  score: 0,
  answered: false,
  completed: false,
  answers: [] // track user's answers for sharing
};

function renderDailyQuizPage() {
  const main = document.getElementById('mainContent');
  const today = getTodayStr();
  const formatted = formatDate(today);

  // Check localStorage for today's completed quiz
  const savedResult = localStorage.getItem('dailyQuiz_' + today);
  if (savedResult) {
    const result = JSON.parse(savedResult);
    renderDailyResult(result.score, result.total, result.dateStr, result.answers, true);
    return;
  }

  const daily = getDailyQuestions();
  dailyState = {
    questions: daily.questions,
    dateStr: daily.dateStr,
    currentIndex: 0,
    score: 0,
    answered: false,
    completed: false,
    answers: []
  };

  main.innerHTML = `
    <div class="category-page daily-quiz-page">
      <div class="breadcrumb">
        <a href="#/">Home</a>
        <span>/</span>
        <span>📅 Daily Practice</span>
      </div>

      <div class="category-hero daily-hero">
        <div class="category-hero-top">
          <div class="category-hero-left">
            <div class="category-hero-emoji">📅</div>
            <div>
              <h1>Daily Russian Practice</h1>
              <p style="color:var(--text-muted);font-size:0.85rem;margin-top:4px">${formatted} — Everyone gets the same quiz today!</p>
            </div>
          </div>
        </div>
        <p class="cat-description">Test your Russian knowledge with today's daily quiz. 10 questions, same for everyone worldwide. Come back tomorrow for a new set!</p>
        <div class="daily-streak" id="dailyStreak"></div>
      </div>

      <div class="daily-quiz-active">
        <div class="quiz-progress">
          <div class="quiz-progress-bar" id="dailyProgressBar"></div>
          <span class="quiz-progress-text" id="dailyProgressText">1/10</span>
        </div>
        <div class="quiz-question" id="dailyQuestion"></div>
        <div class="quiz-answers" id="dailyAnswers"></div>
        <div class="quiz-feedback" id="dailyFeedback" style="display:none"></div>
        <button class="btn-primary quiz-next-btn" id="dailyNextBtn" onclick="dailyNextQuestion()" style="display:none">Next Question</button>
      </div>
    </div>
  `;

  renderDailyStreak();
  renderDailyQuestion();
}

function renderDailyStreak() {
  const streakEl = document.getElementById('dailyStreak');
  if (!streakEl) return;

  // Calculate streak from localStorage
  let streak = 0;
  const today = new Date();
  for (let i = 0; i < 365; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = 'dailyQuiz_' + `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
    if (localStorage.getItem(key)) {
      streak++;
    } else {
      break;
    }
  }

  const totalDone = Object.keys(localStorage).filter(k => k.startsWith('dailyQuiz_')).length;

  streakEl.innerHTML = `
    <div class="streak-badges">
      <div class="streak-badge">
        <span class="streak-num">${streak}</span>
        <span class="streak-label">Day Streak 🔥</span>
      </div>
      <div class="streak-badge">
        <span class="streak-num">${totalDone}</span>
        <span class="streak-label">Quizzes Done</span>
      </div>
    </div>
  `;
}

function renderDailyQuestion() {
  const q = dailyState.questions[dailyState.currentIndex];
  const total = dailyState.questions.length;
  const progress = (dailyState.currentIndex / total) * 100;

  const progressBar = document.getElementById('dailyProgressBar');
  progressBar.innerHTML = '';
  const fill = document.createElement('span');
  fill.className = 'quiz-progress-bar-fill';
  fill.style.width = progress + '%';
  progressBar.appendChild(fill);

  document.getElementById('dailyProgressText').textContent = `${dailyState.currentIndex + 1}/${total}`;
  document.getElementById('dailyQuestion').textContent = q.q;

  const answersDiv = document.getElementById('dailyAnswers');
  answersDiv.innerHTML = '';
  const letters = ['A', 'B', 'C', 'D'];

  q.options.forEach((opt, idx) => {
    const btn = document.createElement('button');
    btn.className = 'quiz-answer-btn';
    btn.innerHTML = `<span class="answer-letter">${letters[idx]}</span><span>${opt}</span>`;
    btn.addEventListener('click', () => dailySelectAnswer(idx));
    answersDiv.appendChild(btn);
  });

  document.getElementById('dailyFeedback').style.display = 'none';
  document.getElementById('dailyNextBtn').style.display = 'none';
  dailyState.answered = false;
}

function dailySelectAnswer(idx) {
  if (dailyState.answered) return;
  dailyState.answered = true;

  const q = dailyState.questions[dailyState.currentIndex];
  const buttons = document.querySelectorAll('#dailyAnswers .quiz-answer-btn');
  const feedback = document.getElementById('dailyFeedback');

  buttons.forEach((btn, i) => {
    btn.style.pointerEvents = 'none';
    if (i === q.answer) btn.classList.add('correct');
    if (i === idx && idx !== q.answer) btn.classList.add('wrong');
  });

  const isCorrect = idx === q.answer;
  if (isCorrect) dailyState.score++;

  // Track answer
  dailyState.answers.push({
    question: q.q,
    correct: isCorrect,
    userAnswer: q.options[idx],
    correctAnswer: q.options[q.answer]
  });

  feedback.className = `quiz-feedback ${isCorrect ? 'correct-fb' : 'wrong-fb'}`;
  feedback.textContent = isCorrect ? '✓ Correct! ' + q.explanation : '✗ Wrong. ' + q.explanation;
  feedback.style.display = '';

  document.getElementById('dailyNextBtn').style.display = '';
  document.getElementById('dailyNextBtn').textContent =
    dailyState.currentIndex < dailyState.questions.length - 1 ? 'Next Question' : 'See Results';
}

function dailyNextQuestion() {
  dailyState.currentIndex++;
  if (dailyState.currentIndex >= dailyState.questions.length) {
    dailyState.completed = true;
    // Save to localStorage
    const result = {
      score: dailyState.score,
      total: dailyState.questions.length,
      dateStr: dailyState.dateStr,
      answers: dailyState.answers,
      timestamp: Date.now()
    };
    localStorage.setItem('dailyQuiz_' + dailyState.dateStr, JSON.stringify(result));
    renderDailyResult(dailyState.score, dailyState.questions.length, dailyState.dateStr, dailyState.answers, false);
  } else {
    renderDailyQuestion();
  }
}

function renderDailyResult(score, total, dateStr, answers, isRevisit) {
  const pct = Math.round((score / total) * 100);
  const formatted = formatDate(dateStr);

  let grade, gradeEmoji, gradeColor;
  if (pct >= 90) { grade = 'S'; gradeEmoji = '🏆'; gradeColor = '#fdcb6e'; }
  else if (pct >= 80) { grade = 'A'; gradeEmoji = '🌟'; gradeColor = '#00b894'; }
  else if (pct >= 60) { grade = 'B'; gradeEmoji = '📚'; gradeColor = '#74b9ff'; }
  else if (pct >= 40) { grade = 'C'; gradeEmoji = '💪'; gradeColor = '#ffa502'; }
  else { grade = 'D'; gradeEmoji = '📖'; gradeColor = '#ff6b6b'; }

  // Build share text
  const shareText = `🇷🇺 Daily Russian Quiz — ${formatted}\n${gradeEmoji} Score: ${score}/${total} (${grade})\n${buildEmojiBar(score, total)}\nPlay today's quiz at:`;

  const main = document.getElementById('mainContent');
  main.innerHTML = `
    <div class="category-page daily-result-page">
      <div class="breadcrumb">
        <a href="#/">Home</a>
        <span>/</span>
        <a href="#/daily">Daily Practice</a>
        <span>/</span>
        <span>Results</span>
      </div>

      <div class="daily-result-card">
        ${isRevisit ? '<div class="daily-revisit-badge">📋 Already completed today</div>' : ''}
        <div class="daily-result-date">${formatted}</div>
        <div class="daily-result-grade" style="color:${gradeColor}">${gradeEmoji} Grade: ${grade}</div>

        <div class="quiz-score-ring" style="margin:24px auto">
          <svg viewBox="0 0 120 120">
            <circle cx="60" cy="60" r="54" fill="none" stroke="var(--border)" stroke-width="8"/>
            <circle class="daily-score-circle" data-pct="${pct}" cx="60" cy="60" r="54" fill="none" stroke="${gradeColor}" stroke-width="8" stroke-dasharray="339.3" stroke-dashoffset="339.3" stroke-linecap="round" transform="rotate(-90 60 60)"/>
          </svg>
          <span class="quiz-score-text">${score}/${total}</span>
        </div>

        <div class="daily-emoji-bar">${buildEmojiBar(score, total)}</div>
        <p class="daily-result-pct" style="color:${gradeColor}">${pct}% Correct</p>

        <div class="daily-share-section">
          <h3>📢 Share Your Result</h3>
          <div class="daily-share-buttons">
            <button class="btn-primary" onclick="shareDailyTwitter('${encodeURIComponent(shareText)}')">𝕏 Share on X</button>
            <button class="btn-secondary" onclick="shareDailyTelegram('${encodeURIComponent(shareText)}')">✈️ Telegram</button>
            <button class="btn-secondary" onclick="shareDailyWhatsApp('${encodeURIComponent(shareText)}')">💬 WhatsApp</button>
            <button class="btn-secondary" onclick="copyDailyResult('${encodeURIComponent(shareText)}')">📋 Copy Result</button>
          </div>
        </div>

        <div class="daily-breakdown">
          <h3>📋 Question Breakdown</h3>
          ${answers.map((a, i) => `
            <div class="daily-breakdown-item ${a.correct ? 'correct' : 'wrong'}">
              <span class="breakdown-num">${i+1}</span>
              <span class="breakdown-icon">${a.correct ? '✓' : '✗'}</span>
              <span class="breakdown-q">${a.question}</span>
              ${!a.correct ? `<span class="breakdown-answer">Yours: ${a.userAnswer} → Correct: ${a.correctAnswer}</span>` : ''}
            </div>
          `).join('')}
        </div>

        <div class="daily-nav-buttons">
          <a href="#/" class="btn-secondary">🏠 Home</a>
          <a href="#/daily" class="btn-primary" onclick="clearDailyAndRetry()">🔄 Try Previous Days</a>
        </div>
      </div>
    </div>
  `;

  // Animate the score circle
  setTimeout(() => {
    const circle = document.querySelector('.daily-score-circle');
    if (circle) {
      const circumference = 2 * Math.PI * 54;
      circle.style.transition = 'stroke-dashoffset 1s ease';
      circle.style.strokeDashoffset = circumference - (circumference * pct / 100);
    }
  }, 200);
}

function buildEmojiBar(score, total) {
  const filled = '🟩';
  const empty = '⬜';
  return filled.repeat(score) + empty.repeat(total - score);
}

function shareDailyTwitter(text) {
  const url = encodeURIComponent(window.location.origin + window.location.pathname + '#/daily');
  window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
}

function shareDailyTelegram(text) {
  const url = encodeURIComponent(window.location.origin + window.location.pathname + '#/daily');
  window.open(`https://t.me/share/url?url=${url}&text=${text}`, '_blank');
}

function shareDailyWhatsApp(text) {
  const url = encodeURIComponent(window.location.origin + window.location.pathname + '#/daily');
  window.open(`https://wa.me/?text=${text}%20${url}`, '_blank');
}

function copyDailyResult(encodedText) {
  const text = decodeURIComponent(encodedText) + ' ' + window.location.origin + window.location.pathname + '#/daily';
  navigator.clipboard.writeText(text).then(() => {
    showToast('Result copied to clipboard!', 'success');
  }).catch(() => showToast('Failed to copy', 'error'));
}

function clearDailyAndRetry() {
  // Just navigate back to daily which will check localStorage
}

// ===== DAILY PRACTICE V2: Word of the Day + Mini Exercise =====
function getDailyWord() {
  const words = [
    { ru: 'Счастье', en: 'Happiness', pron: 'SCHAS-tye', example: 'Счастье — это когда ты рядом.', exampleEn: 'Happiness is when you are near.' },
    { ru: 'Дружба', en: 'Friendship', pron: 'DRUZH-ba', example: 'Дружба дороже золота.', exampleEn: 'Friendship is more precious than gold.' },
    { ru: 'Мечта', en: 'Dream', pron: 'myech-TA', example: 'Мечта сбылась!', exampleEn: 'The dream came true!' },
    { ru: 'Свобода', en: 'Freedom', pron: 'svo-BO-da', example: 'Свобода — это ответственность.', exampleEn: 'Freedom is responsibility.' },
    { ru: 'Красота', en: 'Beauty', pron: 'kra-so-TA', example: 'Красота спасёт мир.', exampleEn: 'Beauty will save the world.' },
    { ru: 'Знание', en: 'Knowledge', pron: 'ZNAY-ni-ye', example: 'Знание — сила.', exampleEn: 'Knowledge is power.' },
    { ru: 'Терпение', en: 'Patience', pron: 'tyer-PYE-ni-ye', example: 'Терпение и труд всё перетрут.', exampleEn: 'Patience and work will grind everything.' },
    { ru: 'Надежда', en: 'Hope', pron: 'na-DEZH-da', example: 'Надежда умирает последней.', exampleEn: 'Hope dies last.' },
    { ru: 'Любовь', en: 'Love', pron: 'lyu-BOV', example: 'Любовь — это самое важное.', exampleEn: 'Love is the most important thing.' },
    { ru: 'Сила', en: 'Strength/Power', pron: 'SEE-la', example: 'В знании — сила.', exampleEn: 'In knowledge there is strength.' },
    { ru: 'Путешествие', en: 'Journey', pron: 'pu-tye-SHEST-vi-ye', example: 'Путешествие начинается с первого шага.', exampleEn: 'A journey begins with the first step.' },
    { ru: 'Природа', en: 'Nature', pron: 'pri-RO-da', example: 'Природа — лучший учитель.', exampleEn: 'Nature is the best teacher.' },
    { ru: 'Мудрость', en: 'Wisdom', pron: 'MOO-drost', example: 'Мудрость приходит с годами.', exampleEn: 'Wisdom comes with age.' },
    { ru: 'Радость', en: 'Joy', pron: 'RA-dost', example: 'Радость — в простых вещах.', exampleEn: 'Joy is in simple things.' },
    { ru: 'Гармония', en: 'Harmony', pron: 'gar-MO-ni-ya', example: 'Гармония внутри нас.', exampleEn: 'Harmony is within us.' },
    { ru: 'Удача', en: 'Luck', pron: 'u-DA-cha', example: 'Удача улыбается смелым.', exampleEn: 'Luck smiles on the brave.' },
    { ru: 'Вдохновение', en: 'Inspiration', pron: 'vdokh-no-VYE-ni-ye', example: 'Вдохновение нужно искать.', exampleEn: 'Inspiration must be sought.' },
    { ru: 'Героизм', en: 'Heroism', pron: 'gye-RO-izm', example: 'Героизм — это поступок во имя других.', exampleEn: 'Heroism is an act in the name of others.' },
    { ru: 'Истина', en: 'Truth', pron: 'IS-ti-na', example: 'Истина всегда одна.', exampleEn: 'The truth is always one.' },
    { ru: 'Смелость', en: 'Courage', pron: 'SME-lost', example: 'Смелость города берёт.', exampleEn: 'Courage takes cities.' },
  ];

  const dateStr = getTodayStr();
  const seed = dateSeed(dateStr);
  const rng = mulberry32(seed);
  const idx = Math.floor(rng() * words.length);
  return words[idx];
}

function renderDailyWordSection() {
  const word = getDailyWord();
  return `
    <div class="daily-word-card">
      <div class="daily-word-label">📝 Word of the Day</div>
      <div class="daily-word-ru">${word.ru}</div>
      <div class="daily-word-pron">[${word.pron}]</div>
      <div class="daily-word-en">${word.en}</div>
      <div class="daily-word-example">
        <div class="daily-word-example-ru">"${word.example}"</div>
        <div class="daily-word-example-en">"${word.exampleEn}"</div>
      </div>
    </div>
  `;
}
