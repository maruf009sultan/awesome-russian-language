/**
 * Simple hash-based router for SPA navigation
 */

const routes = {};
let currentRoute = '';

function route(path, handler) {
  routes[path] = handler;
}

function navigate(path) {
  window.location.hash = path;
}

function getHash() {
  return window.location.hash.slice(1) || '/';
}

function getRouteParams() {
  const hash = getHash();
  const parts = hash.split('/').filter(Boolean);
  return parts;
}

function handleRoute() {
  const hash = getHash();
  currentRoute = hash;

  // Update active sidebar link
  document.querySelectorAll('.sidebar-nav a').forEach(a => {
    a.classList.toggle('active', a.getAttribute('href') === '#' + hash);
  });

  // Scroll to top
  window.scrollTo(0, 0);

  // Route matching
  if (hash === '/' || hash === '') {
    if (routes['/']) routes['/']();
  } else if (hash === '/daily') {
    if (routes['/daily']) routes['/daily']();
  } else if (hash.startsWith('/category/')) {
    const slug = hash.replace('/category/', '');
    if (routes['/category/:slug']) routes['/category/:slug'](slug);
  } else if (hash.startsWith('/search')) {
    const params = new URLSearchParams(hash.split('?')[1] || '');
    if (routes['/search']) routes['/search'](params.get('q') || '');
  } else {
    // 404
    if (routes['404']) routes['404']();
  }
}

// Listen for hash changes
window.addEventListener('hashchange', handleRoute);

// Initial route
window.addEventListener('DOMContentLoaded', () => {
  setTimeout(handleRoute, 100);
});
