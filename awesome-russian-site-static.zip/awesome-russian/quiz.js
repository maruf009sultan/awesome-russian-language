/**
 * Quiz Module - Russian Language Quiz
 */

const quizQuestions = [
  {
    q: "How many letters are in the Russian Cyrillic alphabet?",
    options: ["28", "30", "33", "35"],
    answer: 2,
    explanation: "The Russian Cyrillic alphabet has 33 letters."
  },
  {
    q: "Which Russian letter makes the 'sh' sound as in 'shoe'?",
    options: ["Ч", "Ш", "Ж", "Щ"],
    answer: 1,
    explanation: "Ш is pronounced like 'sh' in 'shoe'. Ч is 'ch', Ж is 'zh', Щ is 'shch'."
  },
  {
    q: "How many grammatical cases does Russian have?",
    options: ["4", "5", "6", "7"],
    answer: 2,
    explanation: "Russian has 6 cases: Nominative, Genitive, Dative, Accusative, Instrumental, and Prepositional."
  },
  {
    q: "What is the Russian word for 'hello' (informal)?",
    options: ["Здравствуйте", "Привет", "До свидания", "Спасибо"],
    answer: 1,
    explanation: "Привет (privet) is the informal 'hello'. Здравствуйте is formal."
  },
  {
    q: "Which case is used to indicate possession ('of') in Russian?",
    options: ["Accusative", "Dative", "Genitive", "Instrumental"],
    answer: 2,
    explanation: "The Genitive case (родительный падеж) indicates possession and corresponds to 'of' in English."
  },
  {
    q: "What does 'до свидания' mean?",
    options: ["Hello", "Thank you", "Goodbye", "Please"],
    answer: 2,
    explanation: "До свидания means 'goodbye' — literally 'until we meet again'."
  },
  {
    q: "What is unusual about the Russian verb system?",
    options: ["It has no past tense", "It uses verbal aspects (perfective/imperfective)", "Verbs don't conjugate", "There are only 3 verbs"],
    answer: 1,
    explanation: "Russian verbs come in aspectual pairs: perfective (completed action) and imperfective (ongoing/repeated action)."
  },
  {
    q: "Which letter is sometimes called the 'hard sign' in Russian?",
    options: ["Ь", "Ъ", "Ы", "Й"],
    answer: 1,
    explanation: "Ъ is the hard sign (твёрдый знак). Ь is the soft sign (мягкий знак)."
  },
  {
    q: "What is the most common greeting in formal Russian?",
    options: ["Привет", "Здорово", "Здравствуйте", "Пока"],
    answer: 2,
    explanation: "Здравствуйте (zdravstvuyte) is the standard formal greeting."
  },
  {
    q: "Which Russian letter has no direct equivalent sound in English?",
    options: ["А", "О", "Ы", "М"],
    answer: 2,
    explanation: "Ы is a unique vowel sound that doesn't exist in English. It's sometimes described as a grunted 'i'."
  },
  {
    q: "What does 'спасибо' mean?",
    options: ["Please", "Sorry", "Thank you", "Hello"],
    answer: 2,
    explanation: "Спасибо (spasibo) means 'thank you'."
  },
  {
    q: "In Russian, which gender are most nouns ending in -а or -я?",
    options: ["Masculine", "Feminine", "Neuter", "Plural"],
    answer: 1,
    explanation: "Most nouns ending in -а or -я are feminine (женский род)."
  },
  {
    q: "What is the Russian word for 'book'?",
    options: ["Книга", "Стол", "Вода", "Дом"],
    answer: 0,
    explanation: "Книга (kniga) means 'book'. Стол is 'table', Вода is 'water', Дом is 'house'."
  },
  {
    q: "Which Russian word means both 'peace' and 'world'?",
    options: ["Земля", "Мир", "Свет", "Жизнь"],
    answer: 1,
    explanation: "Мир (mir) means both 'peace' and 'world'. Context determines the meaning."
  },
  {
    q: "What is the soft sign (Ь) used for in Russian?",
    options: ["To make vowels longer", "To indicate the preceding consonant is palatalized", "To separate words", "To show stress"],
    answer: 1,
    explanation: "The soft sign (Ь) indicates that the preceding consonant is softened/palatalized."
  },
  {
    q: "Which CEFR level is considered 'Upper Intermediate'?",
    options: ["A2", "B1", "B2", "C1"],
    answer: 2,
    explanation: "B2 is Upper Intermediate — can interact with fluency and spontaneity."
  },
  {
    q: "How do you say 'yes' in Russian?",
    options: ["Нет", "Да", "Может", "Хорошо"],
    answer: 1,
    explanation: "Да (da) means 'yes'. Нет (nyet) means 'no'."
  },
  {
    q: "What is 'водка' (vodka) literally derived from?",
    options: ["Water (вода)", "Wheat", "Fire", "Spirit"],
    answer: 0,
    explanation: "Vodka is derived from 'вода' (voda) meaning 'water' — literally 'little water'."
  },
  {
    q: "Which Russian case is used for the direct object of a sentence?",
    options: ["Nominative", "Genitive", "Dative", "Accusative"],
    answer: 3,
    explanation: "The Accusative case (винительный падеж) is used for direct objects."
  },
  {
    q: "What is 'матрёшка'?",
    options: ["A Russian dance", "A nested doll", "A type of bread", "A musical instrument"],
    answer: 1,
    explanation: "Матрёшка (matryoshka) is the famous Russian nesting doll."
  },
  {
    q: "Which letter is the 'soft sign' in Russian?",
    options: ["Ъ", "Ь", "Й", "Ы"],
    answer: 1,
    explanation: "Ь (мягкий знак) is the soft sign. Ъ is the hard sign."
  },
  {
    q: "What is the formal way to say 'you' in Russian?",
    options: ["Ты", "Вы", "Он", "Мы"],
    answer: 1,
    explanation: "Вы (vy) is the formal 'you' and also plural 'you'. Ты (ty) is informal singular."
  },
  {
    q: "Which Russian novelist wrote 'War and Peace'?",
    options: ["Dostoevsky", "Tolstoy", "Chekhov", "Pushkin"],
    answer: 1,
    explanation: "Leo Tolstoy (Лев Толстой) wrote 'War and Peace' (Война и мир)."
  },
  {
    q: "What sound does the letter 'Ж' make?",
    options: ["sh", "zh (like 's' in measure)", "ch", "ts"],
    answer: 1,
    explanation: "Ж is pronounced like 'zh' — similar to the 's' in 'measure' or 'treasure'."
  },
  {
    q: "What is the Russian word for 'please' or 'you're welcome'?",
    options: ["Спасибо", "Пожалуйста", "Извините", "Простите"],
    answer: 1,
    explanation: "Пожалуйста (pozhaluysta) means both 'please' and 'you're welcome'."
  },
  {
    q: "How many tenses does Russian have?",
    options: ["2 (past, present)", "3 (past, present, future)", "4", "6"],
    answer: 1,
    explanation: "Russian has 3 tenses: past, present, and future. However, perfective verbs only have past and future."
  },
  {
    q: "What does 'каша' (kasha) refer to in Russian cuisine?",
    options: ["Soup", "Porridge/grain dish", "Bread", "Salad"],
    answer: 1,
    explanation: "Каша refers to porridge or any grain-based dish — a staple of Russian cuisine."
  },
  {
    q: "Which alphabet does Russian use?",
    options: ["Latin", "Greek", "Cyrillic", "Arabic"],
    answer: 2,
    explanation: "Russian uses the Cyrillic alphabet, named after Saint Cyril."
  },
  {
    q: "What is 'Транссибирская магистраль'?",
    options: ["A Russian ballet", "The Trans-Siberian Railway", "A Siberian mountain range", "A Russian novel"],
    answer: 1,
    explanation: "It's the Trans-Siberian Railway — the longest railway line in the world."
  },
  {
    q: "Which Russian word means 'grandmother'?",
    options: ["Дедушка", "Бабушка", "Мама", "Сестра"],
    answer: 1,
    explanation: "Бабушка (babushka) means 'grandmother'. Дедушка is 'grandfather'."
  }
];

let quizState = {
  active: false,
  questions: [],
  currentIndex: 0,
  score: 0,
  answered: false,
  selectedAnswer: -1
};

function populateQuizCategories(data) {
  const select = document.getElementById('quizCategory');
  if (!select) return;
  select.innerHTML = '<option value="all">All Categories</option>';
  data.categories.forEach(cat => {
    const opt = document.createElement('option');
    opt.value = cat.id;
    opt.textContent = cat.emoji + ' ' + cat.name;
    select.appendChild(opt);
  });
}

function openQuiz() {
  document.getElementById('quizModal').classList.add('active');
  document.getElementById('quizStart').style.display = '';
  document.getElementById('quizActive').style.display = 'none';
  document.getElementById('quizResult').style.display = 'none';
}

function closeQuiz() {
  document.getElementById('quizModal').classList.remove('active');
  quizState.active = false;
}

function startQuiz() {
  const count = parseInt(document.getElementById('quizCount').value);
  const categoryId = document.getElementById('quizCategory').value;

  let pool = [...quizQuestions];

  // Filter by difficulty if category selected (use category to approximate)
  if (categoryId !== 'all' && window._appData) {
    // Mix in some category-related questions by shuffling
    pool = shuffleArray(pool);
  }

  quizState = {
    active: true,
    questions: shuffleArray(pool).slice(0, count),
    currentIndex: 0,
    score: 0,
    answered: false,
    selectedAnswer: -1
  };

  document.getElementById('quizStart').style.display = 'none';
  document.getElementById('quizActive').style.display = '';
  document.getElementById('quizResult').style.display = 'none';

  renderQuestion();
}

function renderQuestion() {
  const q = quizState.questions[quizState.currentIndex];
  const total = quizState.questions.length;
  const progress = ((quizState.currentIndex) / total) * 100;

  const progressBar = document.getElementById('quizProgressBar');
  // Remove old fill and add new one
  progressBar.innerHTML = '';
  const fill = document.createElement('span');
  fill.className = 'quiz-progress-bar-fill';
  fill.style.width = progress + '%';
  progressBar.appendChild(fill);
  document.getElementById('quizProgressText').textContent = `${quizState.currentIndex + 1}/${total}`;
  document.getElementById('quizQuestion').textContent = q.q;

  const answersDiv = document.getElementById('quizAnswers');
  answersDiv.innerHTML = '';
  const letters = ['A', 'B', 'C', 'D'];

  q.options.forEach((opt, idx) => {
    const btn = document.createElement('button');
    btn.className = 'quiz-answer-btn';
    btn.innerHTML = `<span class="answer-letter">${letters[idx]}</span><span>${opt}</span>`;
    btn.addEventListener('click', () => selectAnswer(idx));
    answersDiv.appendChild(btn);
  });

  document.getElementById('quizFeedback').style.display = 'none';
  document.getElementById('quizNextBtn').style.display = 'none';
  quizState.answered = false;
  quizState.selectedAnswer = -1;
}

function selectAnswer(idx) {
  if (quizState.answered) return;
  quizState.answered = true;
  quizState.selectedAnswer = idx;

  const q = quizState.questions[quizState.currentIndex];
  const buttons = document.querySelectorAll('.quiz-answer-btn');
  const feedback = document.getElementById('quizFeedback');

  buttons.forEach((btn, i) => {
    btn.style.pointerEvents = 'none';
    if (i === q.answer) btn.classList.add('correct');
    if (i === idx && idx !== q.answer) btn.classList.add('wrong');
  });

  if (idx === q.answer) {
    quizState.score++;
    feedback.className = 'quiz-feedback correct-fb';
    feedback.textContent = '✓ Correct! ' + q.explanation;
  } else {
    feedback.className = 'quiz-feedback wrong-fb';
    feedback.textContent = '✗ Wrong. ' + q.explanation;
  }
  feedback.style.display = '';

  document.getElementById('quizNextBtn').style.display = '';
  document.getElementById('quizNextBtn').textContent =
    quizState.currentIndex < quizState.questions.length - 1 ? 'Next Question' : 'See Results';
}

function nextQuestion() {
  quizState.currentIndex++;
  if (quizState.currentIndex >= quizState.questions.length) {
    showQuizResult();
  } else {
    renderQuestion();
  }
}

function showQuizResult() {
  document.getElementById('quizActive').style.display = 'none';
  document.getElementById('quizResult').style.display = '';

  const total = quizState.questions.length;
  const score = quizState.score;
  const pct = Math.round((score / total) * 100);

  let icon, title, text;
  if (pct >= 90) { icon = '🏆'; title = 'Outstanding!'; text = 'You\'re a Russian language master!'; }
  else if (pct >= 70) { icon = '🌟'; title = 'Great Job!'; text = 'You know your Russian well!'; }
  else if (pct >= 50) { icon = '📚'; title = 'Good Effort!'; text = 'Keep studying and you\'ll improve!'; }
  else { icon = '💪'; title = 'Keep Learning!'; text = 'Practice makes perfect — try again!'; }

  document.getElementById('quizResultIcon').textContent = icon;
  document.getElementById('quizResultTitle').textContent = title;
  document.getElementById('quizResultText').textContent = text;
  document.getElementById('quizScoreText').textContent = `${score}/${total}`;

  // Animate score circle
  const circle = document.getElementById('quizScoreCircle');
  const circumference = 2 * Math.PI * 54;
  circle.style.strokeDasharray = circumference;
  circle.style.strokeDashoffset = circumference;
  setTimeout(() => {
    circle.style.transition = 'stroke-dashoffset 1s ease';
    circle.style.strokeDashoffset = circumference - (circumference * pct / 100);
  }, 100);
}

function resetQuiz() {
  openQuiz();
}

function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
